import { Component, OnDestroy, OnInit } from '@angular/core';
@Component({
  selector: 'app-hvac',
  templateUrl: './hvac.component.html',
  styleUrls: ['./hvac.component.css']
})
export class HvacComponent implements OnInit, OnDestroy {

  ngOnInit(): void {
    if(!localStorage.getItem("hasRefreshed"))
      setTimeout(() =>  {
        window.location.reload();
        localStorage.setItem("hasRefreshed", "true");
      }, 500);
  }
  ngOnDestroy(): void {
    localStorage.removeItem("hasRefreshed")
  }

  readmore() {
    var moretext = document.getElementById("more")
    console.log(moretext)
  }

}

